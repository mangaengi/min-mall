import { createStore } from 'redux';
import productReduce from './reducers/productReduce'

let store = createStore(productReduce);

export default store;